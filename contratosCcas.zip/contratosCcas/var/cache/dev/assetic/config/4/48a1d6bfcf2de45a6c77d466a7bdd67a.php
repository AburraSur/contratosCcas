<?php

// FOSUserBundle:Security:login.html.twig
return array (
);
