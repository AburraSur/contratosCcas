<?php

// FOSUserBundle:Group:new.html.twig
return array (
);
