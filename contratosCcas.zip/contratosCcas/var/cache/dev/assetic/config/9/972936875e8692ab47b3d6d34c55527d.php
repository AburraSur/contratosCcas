<?php

// TwigBundle:Exception:error.css.twig
return array (
);
