<?php

// WebProfilerBundle:Profiler:toolbar.html.twig
return array (
);
