<?php

// FOSUserBundle:Security:login_content.html.twig
return array (
);
