<?php

// WebProfilerBundle:Profiler:toolbar.css.twig
return array (
);
