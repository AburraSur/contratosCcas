<?php

// TwigBundle:Exception:exception.xml.twig
return array (
);
