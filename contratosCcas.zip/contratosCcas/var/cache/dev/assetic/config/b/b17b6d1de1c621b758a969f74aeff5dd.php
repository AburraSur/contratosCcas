<?php

// WebProfilerBundle:Collector:translation.html.twig
return array (
);
