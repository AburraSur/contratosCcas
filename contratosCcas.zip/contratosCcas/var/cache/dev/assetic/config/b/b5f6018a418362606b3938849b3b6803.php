<?php

// FOSUserBundle:ChangePassword:change_password.html.twig
return array (
);
