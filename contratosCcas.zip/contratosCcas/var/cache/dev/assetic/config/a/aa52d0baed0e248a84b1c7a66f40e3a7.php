<?php

// :tipoparametro:show.html.twig
return array (
  '2c8c367' => 
  array (
    0 => 
    array (
      0 => 'bundles/app/css/*',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/2c8c367.css',
      'name' => '2c8c367',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '6000da4' => 
  array (
    0 => 
    array (
      0 => '@jquery_and_ui',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/6000da4.js',
      'name' => '6000da4',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '9d3a176' => 
  array (
    0 => 
    array (
      0 => 'bundles/app/datatable/css/*',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/9d3a176.css',
      'name' => '9d3a176',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '52788c5' => 
  array (
    0 => 
    array (
      0 => '@AppBundle/Resources/public/datatable/js/*',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/52788c5.js',
      'name' => '52788c5',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
