<?php

// FOSUserBundle:ChangePassword:change_password_content.html.twig
return array (
);
