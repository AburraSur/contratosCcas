<?php

// FOSUserBundle:Group:new_content.html.twig
return array (
);
