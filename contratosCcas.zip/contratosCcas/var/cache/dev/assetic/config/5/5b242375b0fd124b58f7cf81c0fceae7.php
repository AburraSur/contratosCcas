<?php

// FOSUserBundle:Resetting:request.html.twig
return array (
);
