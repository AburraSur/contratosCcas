<?php

// FOSUserBundle:Profile:show.html.twig
return array (
);
