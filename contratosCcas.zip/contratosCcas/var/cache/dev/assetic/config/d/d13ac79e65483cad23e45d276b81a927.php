<?php

// WebProfilerBundle:Collector:twig.html.twig
return array (
);
