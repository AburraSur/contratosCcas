<?php

// FOSUserBundle:Registration:check_email.html.twig
return array (
);
