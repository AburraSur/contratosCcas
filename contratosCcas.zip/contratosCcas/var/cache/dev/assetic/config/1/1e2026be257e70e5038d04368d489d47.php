<?php

// FOSUserBundle:Registration:email.txt.twig
return array (
);
