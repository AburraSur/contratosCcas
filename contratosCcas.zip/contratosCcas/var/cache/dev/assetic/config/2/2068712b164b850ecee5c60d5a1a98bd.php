<?php

// FOSUserBundle:Resetting:check_email.html.twig
return array (
);
