<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_f07671d675060bd4b2cf89f905290449851708364969c89f1f5c079c1c64b8a3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_845042dc12082fce9dbb28800d39d797d77014d27157388f7dcfb18e6fe5f10b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_845042dc12082fce9dbb28800d39d797d77014d27157388f7dcfb18e6fe5f10b->enter($__internal_845042dc12082fce9dbb28800d39d797d77014d27157388f7dcfb18e6fe5f10b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_845042dc12082fce9dbb28800d39d797d77014d27157388f7dcfb18e6fe5f10b->leave($__internal_845042dc12082fce9dbb28800d39d797d77014d27157388f7dcfb18e6fe5f10b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_options.html.php");
    }
}
