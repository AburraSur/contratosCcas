<?php

/* parametros/show.html.twig */
class __TwigTemplate_6aa21c72553c5df82f696ceca481537648a63cb0d7937e5a325f678068f71882 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "parametros/show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5fa7526f5a3e35a73bc4a64ed7b0e238dd7376205941046304bdb58566980242 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5fa7526f5a3e35a73bc4a64ed7b0e238dd7376205941046304bdb58566980242->enter($__internal_5fa7526f5a3e35a73bc4a64ed7b0e238dd7376205941046304bdb58566980242_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "parametros/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5fa7526f5a3e35a73bc4a64ed7b0e238dd7376205941046304bdb58566980242->leave($__internal_5fa7526f5a3e35a73bc4a64ed7b0e238dd7376205941046304bdb58566980242_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_e667ddcd4300d3ccd810b6c69baa996ee91aa8c003c2f7f4aff998484146c6f7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e667ddcd4300d3ccd810b6c69baa996ee91aa8c003c2f7f4aff998484146c6f7->enter($__internal_e667ddcd4300d3ccd810b6c69baa996ee91aa8c003c2f7f4aff998484146c6f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Parametro</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["parametro"]) ? $context["parametro"] : $this->getContext($context, "parametro")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Descripcion</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["parametro"]) ? $context["parametro"] : $this->getContext($context, "parametro")), "descripcion", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Current</th>
                <td>";
        // line 18
        if ($this->getAttribute((isset($context["parametro"]) ? $context["parametro"] : $this->getContext($context, "parametro")), "current", array())) {
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["parametro"]) ? $context["parametro"] : $this->getContext($context, "parametro")), "current", array()), "Y-m-d"), "html", null, true);
        }
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("parametros_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            <a href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("parametros_edit", array("id" => $this->getAttribute((isset($context["parametro"]) ? $context["parametro"] : $this->getContext($context, "parametro")), "id", array()))), "html", null, true);
        echo "\">Edit</a>
        </li>
        <li>
            ";
        // line 31
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 33
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_e667ddcd4300d3ccd810b6c69baa996ee91aa8c003c2f7f4aff998484146c6f7->leave($__internal_e667ddcd4300d3ccd810b6c69baa996ee91aa8c003c2f7f4aff998484146c6f7_prof);

    }

    public function getTemplateName()
    {
        return "parametros/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 33,  86 => 31,  80 => 28,  74 => 25,  62 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Parametro</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ parametro.id }}</td>
            </tr>
            <tr>
                <th>Descripcion</th>
                <td>{{ parametro.descripcion }}</td>
            </tr>
            <tr>
                <th>Current</th>
                <td>{% if parametro.current %}{{ parametro.current|date('Y-m-d') }}{% endif %}</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('parametros_index') }}\">Back to the list</a>
        </li>
        <li>
            <a href=\"{{ path('parametros_edit', { 'id': parametro.id }) }}\">Edit</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", "parametros/show.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\app\\Resources\\views\\parametros\\show.html.twig");
    }
}
