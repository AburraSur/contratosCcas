<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_5e7306c0674582bab0f75a332345576d43a1576df8ca59e5690b3e9c555f9d92 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d59eb71cb648606f2ae670e63e23a18b6b34ff0e48795f4b17278a1d45b9a2b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d59eb71cb648606f2ae670e63e23a18b6b34ff0e48795f4b17278a1d45b9a2b0->enter($__internal_d59eb71cb648606f2ae670e63e23a18b6b34ff0e48795f4b17278a1d45b9a2b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d59eb71cb648606f2ae670e63e23a18b6b34ff0e48795f4b17278a1d45b9a2b0->leave($__internal_d59eb71cb648606f2ae670e63e23a18b6b34ff0e48795f4b17278a1d45b9a2b0_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_24f5d309424def192e7bc8cf6ee53f02666961a4d72d27af1a4b3b791f2382e2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_24f5d309424def192e7bc8cf6ee53f02666961a4d72d27af1a4b3b791f2382e2->enter($__internal_24f5d309424def192e7bc8cf6ee53f02666961a4d72d27af1a4b3b791f2382e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_24f5d309424def192e7bc8cf6ee53f02666961a4d72d27af1a4b3b791f2382e2->leave($__internal_24f5d309424def192e7bc8cf6ee53f02666961a4d72d27af1a4b3b791f2382e2_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_8457add293d784694a8c938bb909781bd7669c12a850d742949dd7fb28943d8a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8457add293d784694a8c938bb909781bd7669c12a850d742949dd7fb28943d8a->enter($__internal_8457add293d784694a8c938bb909781bd7669c12a850d742949dd7fb28943d8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_8457add293d784694a8c938bb909781bd7669c12a850d742949dd7fb28943d8a->leave($__internal_8457add293d784694a8c938bb909781bd7669c12a850d742949dd7fb28943d8a_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "@WebProfiler/Profiler/toolbar_redirect.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\toolbar_redirect.html.twig");
    }
}
