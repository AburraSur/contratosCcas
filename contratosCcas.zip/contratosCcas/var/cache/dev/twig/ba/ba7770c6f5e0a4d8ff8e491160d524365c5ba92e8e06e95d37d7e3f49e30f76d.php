<?php

/* FOSUserBundle:Resetting:request.html.twig */
class __TwigTemplate_64a2d62fd69c7f5f81608d1ea16e683df15eae3dab335fe787e4360988e1c52e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:request.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b302880a4b7a916bf9dc88935cd4844991848fcf7e376afe7c63498c5430933b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b302880a4b7a916bf9dc88935cd4844991848fcf7e376afe7c63498c5430933b->enter($__internal_b302880a4b7a916bf9dc88935cd4844991848fcf7e376afe7c63498c5430933b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b302880a4b7a916bf9dc88935cd4844991848fcf7e376afe7c63498c5430933b->leave($__internal_b302880a4b7a916bf9dc88935cd4844991848fcf7e376afe7c63498c5430933b_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_cd0884d02f752464b53310cef02913cad7889c1b1fea2fedf4096124eeae17ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd0884d02f752464b53310cef02913cad7889c1b1fea2fedf4096124eeae17ea->enter($__internal_cd0884d02f752464b53310cef02913cad7889c1b1fea2fedf4096124eeae17ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Resetting/request_content.html.twig", "FOSUserBundle:Resetting:request.html.twig", 4)->display($context);
        
        $__internal_cd0884d02f752464b53310cef02913cad7889c1b1fea2fedf4096124eeae17ea->leave($__internal_cd0884d02f752464b53310cef02913cad7889c1b1fea2fedf4096124eeae17ea_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Resetting/request_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Resetting:request.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle/Resources/views/Resetting/request.html.twig");
    }
}
