<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_e9d848f56ac6e17674ff6db2fb01758fe3d7e4ef940f489b5ba3446c44ed1c44 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_68be327247bf5ac4fec7bd155e29e20ad22a227c9df9452807c828e7c14d276a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_68be327247bf5ac4fec7bd155e29e20ad22a227c9df9452807c828e7c14d276a->enter($__internal_68be327247bf5ac4fec7bd155e29e20ad22a227c9df9452807c828e7c14d276a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_68be327247bf5ac4fec7bd155e29e20ad22a227c9df9452807c828e7c14d276a->leave($__internal_68be327247bf5ac4fec7bd155e29e20ad22a227c9df9452807c828e7c14d276a_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_84598fb21921d8de31a77c93469d40ec3336ecd8b0ce2367f4e64f8e3cf4713e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84598fb21921d8de31a77c93469d40ec3336ecd8b0ce2367f4e64f8e3cf4713e->enter($__internal_84598fb21921d8de31a77c93469d40ec3336ecd8b0ce2367f4e64f8e3cf4713e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Profile/show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_84598fb21921d8de31a77c93469d40ec3336ecd8b0ce2367f4e64f8e3cf4713e->leave($__internal_84598fb21921d8de31a77c93469d40ec3336ecd8b0ce2367f4e64f8e3cf4713e_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Profile/show_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Profile:show.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle/Resources/views/Profile/show.html.twig");
    }
}
