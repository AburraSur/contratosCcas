<?php

/* @FOSUser/Group/show.html.twig */
class __TwigTemplate_1ac9aa2450a4a662956fca58bed0f7b6dc39ddd0345a307a07c6de119b43a7de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Group/show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eb8e65ae9842e3d37d70f80b46cd8d9139693f87764f60f54685919ff29fbde7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb8e65ae9842e3d37d70f80b46cd8d9139693f87764f60f54685919ff29fbde7->enter($__internal_eb8e65ae9842e3d37d70f80b46cd8d9139693f87764f60f54685919ff29fbde7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Group/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_eb8e65ae9842e3d37d70f80b46cd8d9139693f87764f60f54685919ff29fbde7->leave($__internal_eb8e65ae9842e3d37d70f80b46cd8d9139693f87764f60f54685919ff29fbde7_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_256fe7d635cac4a0b12af77bbfc674a70a6cc31da77810c21419e502b2d9414d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_256fe7d635cac4a0b12af77bbfc674a70a6cc31da77810c21419e502b2d9414d->enter($__internal_256fe7d635cac4a0b12af77bbfc674a70a6cc31da77810c21419e502b2d9414d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/show_content.html.twig", "@FOSUser/Group/show.html.twig", 4)->display($context);
        
        $__internal_256fe7d635cac4a0b12af77bbfc674a70a6cc31da77810c21419e502b2d9414d->leave($__internal_256fe7d635cac4a0b12af77bbfc674a70a6cc31da77810c21419e502b2d9414d_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Group/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/show_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Group/show.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Group\\show.html.twig");
    }
}
