<?php

/* @FOSUser/Resetting/check_email.html.twig */
class __TwigTemplate_0069f1844f7732d6d64718e4bc1170cbd93e715b5adfd0bdea3002c506cd185b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Resetting/check_email.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f0c7dc77dd1fd65dff1a882438ffb3e95c52f7f3719e805d7f2d7b7dcb7f45bf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0c7dc77dd1fd65dff1a882438ffb3e95c52f7f3719e805d7f2d7b7dcb7f45bf->enter($__internal_f0c7dc77dd1fd65dff1a882438ffb3e95c52f7f3719e805d7f2d7b7dcb7f45bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Resetting/check_email.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f0c7dc77dd1fd65dff1a882438ffb3e95c52f7f3719e805d7f2d7b7dcb7f45bf->leave($__internal_f0c7dc77dd1fd65dff1a882438ffb3e95c52f7f3719e805d7f2d7b7dcb7f45bf_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_ffe6c71cc8a16fff77e823ccbfe2a0098f9ff91e04ce01de76d4c0c769c3bae8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ffe6c71cc8a16fff77e823ccbfe2a0098f9ff91e04ce01de76d4c0c769c3bae8->enter($__internal_ffe6c71cc8a16fff77e823ccbfe2a0098f9ff91e04ce01de76d4c0c769c3bae8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>
";
        // line 7
        echo nl2br(twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.check_email", array("%tokenLifetime%" => (isset($context["tokenLifetime"]) ? $context["tokenLifetime"] : $this->getContext($context, "tokenLifetime"))), "FOSUserBundle"), "html", null, true));
        echo "
</p>
";
        
        $__internal_ffe6c71cc8a16fff77e823ccbfe2a0098f9ff91e04ce01de76d4c0c769c3bae8->leave($__internal_ffe6c71cc8a16fff77e823ccbfe2a0098f9ff91e04ce01de76d4c0c769c3bae8_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Resetting/check_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 7,  40 => 6,  34 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
<p>
{{ 'resetting.check_email'|trans({'%tokenLifetime%': tokenLifetime})|nl2br }}
</p>
{% endblock %}
", "@FOSUser/Resetting/check_email.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Resetting\\check_email.html.twig");
    }
}
