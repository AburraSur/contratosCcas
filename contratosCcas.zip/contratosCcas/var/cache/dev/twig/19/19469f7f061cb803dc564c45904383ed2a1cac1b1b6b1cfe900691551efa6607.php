<?php

/* tipoparametro/new.html.twig */
class __TwigTemplate_93be2bc15b981029e25e7f6080f574e8fafa3803ea9ecaba7c108fdf0f06dba7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "tipoparametro/new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2dffbdd4ea7c7e5f05889cdcb0f9845b86a7ee6816a83b92b1a637a607c8c301 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2dffbdd4ea7c7e5f05889cdcb0f9845b86a7ee6816a83b92b1a637a607c8c301->enter($__internal_2dffbdd4ea7c7e5f05889cdcb0f9845b86a7ee6816a83b92b1a637a607c8c301_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "tipoparametro/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2dffbdd4ea7c7e5f05889cdcb0f9845b86a7ee6816a83b92b1a637a607c8c301->leave($__internal_2dffbdd4ea7c7e5f05889cdcb0f9845b86a7ee6816a83b92b1a637a607c8c301_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_a07331cfa7e2da317e6db8e62e410658788fafb6a22f3888a73bedf4698a76bc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a07331cfa7e2da317e6db8e62e410658788fafb6a22f3888a73bedf4698a76bc->enter($__internal_a07331cfa7e2da317e6db8e62e410658788fafb6a22f3888a73bedf4698a76bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Tipoparametro creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("tipoparametro_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_a07331cfa7e2da317e6db8e62e410658788fafb6a22f3888a73bedf4698a76bc->leave($__internal_a07331cfa7e2da317e6db8e62e410658788fafb6a22f3888a73bedf4698a76bc_prof);

    }

    public function getTemplateName()
    {
        return "tipoparametro/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Tipoparametro creation</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input type=\"submit\" value=\"Create\" />
    {{ form_end(form) }}

    <ul>
        <li>
            <a href=\"{{ path('tipoparametro_index') }}\">Back to the list</a>
        </li>
    </ul>
{% endblock %}
", "tipoparametro/new.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\app\\Resources\\views\\tipoparametro\\new.html.twig");
    }
}
