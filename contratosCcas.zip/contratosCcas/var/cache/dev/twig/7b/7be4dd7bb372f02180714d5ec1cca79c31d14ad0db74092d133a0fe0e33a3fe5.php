<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_2cfadf8fad90051129a1db620d0f36c34af538b902cfc71a083036d7ab660394 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6448575fd11cd6268d8c798f08483c1f10cc44ad4b23fc60a91e72a6b72dc0af = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6448575fd11cd6268d8c798f08483c1f10cc44ad4b23fc60a91e72a6b72dc0af->enter($__internal_6448575fd11cd6268d8c798f08483c1f10cc44ad4b23fc60a91e72a6b72dc0af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6448575fd11cd6268d8c798f08483c1f10cc44ad4b23fc60a91e72a6b72dc0af->leave($__internal_6448575fd11cd6268d8c798f08483c1f10cc44ad4b23fc60a91e72a6b72dc0af_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_46c87f1476f98113bf7801a9a59addb9f3261e95bc36d04bb2089da9a4a3fdcc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_46c87f1476f98113bf7801a9a59addb9f3261e95bc36d04bb2089da9a4a3fdcc->enter($__internal_46c87f1476f98113bf7801a9a59addb9f3261e95bc36d04bb2089da9a4a3fdcc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_46c87f1476f98113bf7801a9a59addb9f3261e95bc36d04bb2089da9a4a3fdcc->leave($__internal_46c87f1476f98113bf7801a9a59addb9f3261e95bc36d04bb2089da9a4a3fdcc_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_4fb91de916bed0589e454281e23ce0c7d266eedf6554a3618bb46a951c9ed654 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4fb91de916bed0589e454281e23ce0c7d266eedf6554a3618bb46a951c9ed654->enter($__internal_4fb91de916bed0589e454281e23ce0c7d266eedf6554a3618bb46a951c9ed654_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_4fb91de916bed0589e454281e23ce0c7d266eedf6554a3618bb46a951c9ed654->leave($__internal_4fb91de916bed0589e454281e23ce0c7d266eedf6554a3618bb46a951c9ed654_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_053664a003a47591590a6b8037652bb52786be452a227b3ef6647ba7a8263195 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_053664a003a47591590a6b8037652bb52786be452a227b3ef6647ba7a8263195->enter($__internal_053664a003a47591590a6b8037652bb52786be452a227b3ef6647ba7a8263195_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_053664a003a47591590a6b8037652bb52786be452a227b3ef6647ba7a8263195->leave($__internal_053664a003a47591590a6b8037652bb52786be452a227b3ef6647ba7a8263195_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception_full.html.twig");
    }
}
