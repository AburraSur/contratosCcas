<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_95238bec749b990bfdb9abbf94a924922c81600e8ec1036a5abafa637f5f0054 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d6fd9187afd1de693f7191fe423095dff0e80c90f95899fcd7cf475c0ec6af82 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d6fd9187afd1de693f7191fe423095dff0e80c90f95899fcd7cf475c0ec6af82->enter($__internal_d6fd9187afd1de693f7191fe423095dff0e80c90f95899fcd7cf475c0ec6af82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d6fd9187afd1de693f7191fe423095dff0e80c90f95899fcd7cf475c0ec6af82->leave($__internal_d6fd9187afd1de693f7191fe423095dff0e80c90f95899fcd7cf475c0ec6af82_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_cd8931952a15cf4bde9d33dc8853a4763a3f773ce83db779fa265a0640922b0f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd8931952a15cf4bde9d33dc8853a4763a3f773ce83db779fa265a0640922b0f->enter($__internal_cd8931952a15cf4bde9d33dc8853a4763a3f773ce83db779fa265a0640922b0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Registration/register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_cd8931952a15cf4bde9d33dc8853a4763a3f773ce83db779fa265a0640922b0f->leave($__internal_cd8931952a15cf4bde9d33dc8853a4763a3f773ce83db779fa265a0640922b0f_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Registration/register_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:register.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle/Resources/views/Registration/register.html.twig");
    }
}
