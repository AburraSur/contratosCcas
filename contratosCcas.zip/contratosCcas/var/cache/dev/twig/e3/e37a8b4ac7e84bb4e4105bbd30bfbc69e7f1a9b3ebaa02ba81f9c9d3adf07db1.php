<?php

/* FOSUserBundle:Resetting:email.txt.twig */
class __TwigTemplate_d4841d889852ccd4d43db7852003ba4a10a0d6ae2404ef94ffd927776d418677 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f2a906ab18c95826df77e767ad6c46563207dc8c9f06f857276dff869f66b392 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2a906ab18c95826df77e767ad6c46563207dc8c9f06f857276dff869f66b392->enter($__internal_f2a906ab18c95826df77e767ad6c46563207dc8c9f06f857276dff869f66b392_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('body_text', $context, $blocks);
        // line 13
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_f2a906ab18c95826df77e767ad6c46563207dc8c9f06f857276dff869f66b392->leave($__internal_f2a906ab18c95826df77e767ad6c46563207dc8c9f06f857276dff869f66b392_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_52f194f5c2c8c62d86336477e7bcded8a45f70dcf813d3d5a872bd0fd3bf5fe6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_52f194f5c2c8c62d86336477e7bcded8a45f70dcf813d3d5a872bd0fd3bf5fe6->enter($__internal_52f194f5c2c8c62d86336477e7bcded8a45f70dcf813d3d5a872bd0fd3bf5fe6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array())), "FOSUserBundle");
        
        $__internal_52f194f5c2c8c62d86336477e7bcded8a45f70dcf813d3d5a872bd0fd3bf5fe6->leave($__internal_52f194f5c2c8c62d86336477e7bcded8a45f70dcf813d3d5a872bd0fd3bf5fe6_prof);

    }

    // line 8
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_22cd269c528c4d2fe4f65178cf63f5d7900bdc21f46cbfc1191d9c76c769ed49 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22cd269c528c4d2fe4f65178cf63f5d7900bdc21f46cbfc1191d9c76c769ed49->enter($__internal_22cd269c528c4d2fe4f65178cf63f5d7900bdc21f46cbfc1191d9c76c769ed49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_22cd269c528c4d2fe4f65178cf63f5d7900bdc21f46cbfc1191d9c76c769ed49->leave($__internal_22cd269c528c4d2fe4f65178cf63f5d7900bdc21f46cbfc1191d9c76c769ed49_prof);

    }

    // line 13
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_7adcf9714062d38b09ad930ad89990587e6563127606015f18bd1b6209e863e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7adcf9714062d38b09ad930ad89990587e6563127606015f18bd1b6209e863e0->enter($__internal_7adcf9714062d38b09ad930ad89990587e6563127606015f18bd1b6209e863e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_7adcf9714062d38b09ad930ad89990587e6563127606015f18bd1b6209e863e0->leave($__internal_7adcf9714062d38b09ad930ad89990587e6563127606015f18bd1b6209e863e0_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  67 => 13,  58 => 10,  52 => 8,  45 => 4,  39 => 2,  32 => 13,  30 => 8,  27 => 7,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}
{% block subject %}
{%- autoescape false -%}
{{ 'resetting.email.subject'|trans({'%username%': user.username}) }}
{%- endautoescape -%}
{% endblock %}

{% block body_text %}
{% autoescape false %}
{{ 'resetting.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endautoescape %}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Resetting:email.txt.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle/Resources/views/Resetting/email.txt.twig");
    }
}
