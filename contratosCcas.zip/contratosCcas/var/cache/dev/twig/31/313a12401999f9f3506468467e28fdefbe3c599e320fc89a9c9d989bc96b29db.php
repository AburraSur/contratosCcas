<?php

/* FOSUserBundle:Registration:check_email.html.twig */
class __TwigTemplate_5d1a972c88ebd9fe2c16a5f3f42c41bf429d9e054dffc7b0a950801926f3916d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Registration:check_email.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6da65d1f235f962de8394f2d6165e7e44272b18ca170907491ef3e5cd2bde5a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6da65d1f235f962de8394f2d6165e7e44272b18ca170907491ef3e5cd2bde5a6->enter($__internal_6da65d1f235f962de8394f2d6165e7e44272b18ca170907491ef3e5cd2bde5a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:check_email.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6da65d1f235f962de8394f2d6165e7e44272b18ca170907491ef3e5cd2bde5a6->leave($__internal_6da65d1f235f962de8394f2d6165e7e44272b18ca170907491ef3e5cd2bde5a6_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_8a73ba840945d86a291dcdf8d204ddba0fecfc9c0d228e186a5245872f314748 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a73ba840945d86a291dcdf8d204ddba0fecfc9c0d228e186a5245872f314748->enter($__internal_8a73ba840945d86a291dcdf8d204ddba0fecfc9c0d228e186a5245872f314748_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.check_email", array("%email%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_8a73ba840945d86a291dcdf8d204ddba0fecfc9c0d228e186a5245872f314748->leave($__internal_8a73ba840945d86a291dcdf8d204ddba0fecfc9c0d228e186a5245872f314748_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:check_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
    <p>{{ 'registration.check_email'|trans({'%email%': user.email}) }}</p>
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:check_email.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle/Resources/views/Registration/check_email.html.twig");
    }
}
