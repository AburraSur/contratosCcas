<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_1d37406f436a937caffdb73e02b3abbc03581ae4740b7d4c16deb8182de6d8ae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_773c04f8061b0a8c0e5199cd04b867d8ae689d46212b167eb6ad9db799bf430b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_773c04f8061b0a8c0e5199cd04b867d8ae689d46212b167eb6ad9db799bf430b->enter($__internal_773c04f8061b0a8c0e5199cd04b867d8ae689d46212b167eb6ad9db799bf430b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_773c04f8061b0a8c0e5199cd04b867d8ae689d46212b167eb6ad9db799bf430b->leave($__internal_773c04f8061b0a8c0e5199cd04b867d8ae689d46212b167eb6ad9db799bf430b_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_a965368a626b14c5a411097b9b9f02191c60047c0bbfbe3ecab0838d1d05b172 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a965368a626b14c5a411097b9b9f02191c60047c0bbfbe3ecab0838d1d05b172->enter($__internal_a965368a626b14c5a411097b9b9f02191c60047c0bbfbe3ecab0838d1d05b172_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_a965368a626b14c5a411097b9b9f02191c60047c0bbfbe3ecab0838d1d05b172->leave($__internal_a965368a626b14c5a411097b9b9f02191c60047c0bbfbe3ecab0838d1d05b172_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
