<?php

/* @FOSUser/Resetting/request.html.twig */
class __TwigTemplate_d52d73dd10c1afb3f1858b300c0cf7767e2a55d0ae215abf0b28a7bff2a06fb2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Resetting/request.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_492addd9ec35ddb738cc91ffbc87e1f8c4cc2d9613304b60ea310344aa3c6e21 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_492addd9ec35ddb738cc91ffbc87e1f8c4cc2d9613304b60ea310344aa3c6e21->enter($__internal_492addd9ec35ddb738cc91ffbc87e1f8c4cc2d9613304b60ea310344aa3c6e21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Resetting/request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_492addd9ec35ddb738cc91ffbc87e1f8c4cc2d9613304b60ea310344aa3c6e21->leave($__internal_492addd9ec35ddb738cc91ffbc87e1f8c4cc2d9613304b60ea310344aa3c6e21_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_2d197938d6089e86608c54c5651989b9ab3123664f7724ee3c823acfb3e1c127 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2d197938d6089e86608c54c5651989b9ab3123664f7724ee3c823acfb3e1c127->enter($__internal_2d197938d6089e86608c54c5651989b9ab3123664f7724ee3c823acfb3e1c127_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Resetting/request_content.html.twig", "@FOSUser/Resetting/request.html.twig", 4)->display($context);
        
        $__internal_2d197938d6089e86608c54c5651989b9ab3123664f7724ee3c823acfb3e1c127->leave($__internal_2d197938d6089e86608c54c5651989b9ab3123664f7724ee3c823acfb3e1c127_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Resetting/request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Resetting/request_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Resetting/request.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Resetting\\request.html.twig");
    }
}
