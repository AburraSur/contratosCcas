<?php

/* ::base1.html.twig */
class __TwigTemplate_9b01e431f5a203fcd8af4193b3e50aa78dd0d3107e12e26774eaabd3ca2aebaf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c45e123aa76a8793317c51cd67a5a6247f3fa83dd74d802d73c37ee7a66b35e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c45e123aa76a8793317c51cd67a5a6247f3fa83dd74d802d73c37ee7a66b35e7->enter($__internal_c45e123aa76a8793317c51cd67a5a6247f3fa83dd74d802d73c37ee7a66b35e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base1.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        ";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        // line 6
        echo "       ";
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        ";
        // line 13
        $this->displayBlock('content', $context, $blocks);
        // line 15
        echo "    </body>
    ";
        // line 16
        $this->displayBlock('javascripts', $context, $blocks);
        // line 33
        echo " 
</html>
";
        
        $__internal_c45e123aa76a8793317c51cd67a5a6247f3fa83dd74d802d73c37ee7a66b35e7->leave($__internal_c45e123aa76a8793317c51cd67a5a6247f3fa83dd74d802d73c37ee7a66b35e7_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_db9b5e1d9bdc7ea49196b568452a640c7f54a8d117849983c40ab0b5d5229350 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db9b5e1d9bdc7ea49196b568452a640c7f54a8d117849983c40ab0b5d5229350->enter($__internal_db9b5e1d9bdc7ea49196b568452a640c7f54a8d117849983c40ab0b5d5229350_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "        ";
        
        $__internal_db9b5e1d9bdc7ea49196b568452a640c7f54a8d117849983c40ab0b5d5229350->leave($__internal_db9b5e1d9bdc7ea49196b568452a640c7f54a8d117849983c40ab0b5d5229350_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ba6fd01e7d62f9ce9fde0210305dc241e97a91ab434d7444cb6305d9633d2619 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ba6fd01e7d62f9ce9fde0210305dc241e97a91ab434d7444cb6305d9633d2619->enter($__internal_ba6fd01e7d62f9ce9fde0210305dc241e97a91ab434d7444cb6305d9633d2619_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "            ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "2c8c367_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_bootstrap-datepicker_1.css");
            // line 8
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_1") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_bootstrap-select_2.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_2") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_bootstrap-theme.min_3.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_3") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_bootstrap-theme.min.css_4.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_4") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_bootstrap.min_5.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_5"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_5") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_bootstrap.min.css_6.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_6"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_6") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_font-awesome_7.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_7"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_7") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_font-awesome.min_8.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_8"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_8") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_morris_9.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_9"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_9") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_sb-admin-rtl_10.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_10"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_10") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_sb-admin_11.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
        } else {
            // asset "2c8c367"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
        }
        unset($context["asset_url"]);
        // line 10
        echo "        ";
        
        $__internal_ba6fd01e7d62f9ce9fde0210305dc241e97a91ab434d7444cb6305d9633d2619->leave($__internal_ba6fd01e7d62f9ce9fde0210305dc241e97a91ab434d7444cb6305d9633d2619_prof);

    }

    // line 13
    public function block_content($context, array $blocks = array())
    {
        $__internal_4b4242dfde2b037cff5efa58bef298b968567718e8b1250fd9a05b22f3d65908 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b4242dfde2b037cff5efa58bef298b968567718e8b1250fd9a05b22f3d65908->enter($__internal_4b4242dfde2b037cff5efa58bef298b968567718e8b1250fd9a05b22f3d65908_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 14
        echo "        ";
        
        $__internal_4b4242dfde2b037cff5efa58bef298b968567718e8b1250fd9a05b22f3d65908->leave($__internal_4b4242dfde2b037cff5efa58bef298b968567718e8b1250fd9a05b22f3d65908_prof);

    }

    // line 16
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_9498953af3633ceb1c8f05735f7e8439863c57bbfec7233e92d9f5885232c13b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9498953af3633ceb1c8f05735f7e8439863c57bbfec7233e92d9f5885232c13b->enter($__internal_9498953af3633ceb1c8f05735f7e8439863c57bbfec7233e92d9f5885232c13b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 17
        echo "            ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "6000da4_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_6000da4_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/6000da4_part_1.js");
            // line 19
            echo "                <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
            ";
        } else {
            // asset "6000da4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_6000da4") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/6000da4.js");
            echo "                <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
            ";
        }
        unset($context["asset_url"]);
        // line 21
        echo "            
            <script>
                \$(document).ready(function() {
                    \$('.datepicker').datepicker({
                        format: 'yyyy-mm-dd',
                        language: 'es',
                        autoclose: true
                    });
                    
                    \$('.selectpicker').selectpicker();
                });
            </script>
        ";
        
        $__internal_9498953af3633ceb1c8f05735f7e8439863c57bbfec7233e92d9f5885232c13b->leave($__internal_9498953af3633ceb1c8f05735f7e8439863c57bbfec7233e92d9f5885232c13b_prof);

    }

    public function getTemplateName()
    {
        return "::base1.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  199 => 21,  185 => 19,  180 => 17,  174 => 16,  167 => 14,  161 => 13,  154 => 10,  80 => 8,  75 => 7,  69 => 6,  62 => 5,  56 => 4,  47 => 33,  45 => 16,  42 => 15,  40 => 13,  36 => 11,  33 => 6,  31 => 4,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        {% block title %}
        {% endblock title %}
       {% block stylesheets %}
            {% stylesheets 'bundles/app/css/*' filter='cssrewrite' %}
                <link rel=\"stylesheet\" href=\"{{ asset_url }}\" />
            {% endstylesheets %}
        {% endblock %}
    </head>
    <body>
        {% block content %}
        {% endblock content %}
    </body>
    {% block javascripts %}
            {% javascripts 
                '@jquery_and_ui' %}
                <script src=\"{{ asset_url }}\"></script>
            {% endjavascripts %}
            
            <script>
                \$(document).ready(function() {
                    \$('.datepicker').datepicker({
                        format: 'yyyy-mm-dd',
                        language: 'es',
                        autoclose: true
                    });
                    
                    \$('.selectpicker').selectpicker();
                });
            </script>
        {% endblock %} 
</html>
", "::base1.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\app/Resources\\views/base1.html.twig");
    }
}
