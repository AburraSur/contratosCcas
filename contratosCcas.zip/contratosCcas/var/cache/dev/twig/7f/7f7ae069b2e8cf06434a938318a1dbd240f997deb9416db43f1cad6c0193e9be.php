<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_4ccc488fda74674ed72a0d14cd445331e2122ac070e29a7ece242b0615276358 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0b58cf7141c1cacb08afb050cca07e0a3c777d22b2537cac8279f5f3a53aee8a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b58cf7141c1cacb08afb050cca07e0a3c777d22b2537cac8279f5f3a53aee8a->enter($__internal_0b58cf7141c1cacb08afb050cca07e0a3c777d22b2537cac8279f5f3a53aee8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_0b58cf7141c1cacb08afb050cca07e0a3c777d22b2537cac8279f5f3a53aee8a->leave($__internal_0b58cf7141c1cacb08afb050cca07e0a3c777d22b2537cac8279f5f3a53aee8a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_row.html.php");
    }
}
