<?php

/* base1.html.twig */
class __TwigTemplate_fd6b4cae9a4e0bab59c79935175f169010ba8459992305715ad18a2a77a49230 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_296f76f59690c2f5ddf234a9ab509f9e3b356f88b69d01e965b8501f2ab9c712 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_296f76f59690c2f5ddf234a9ab509f9e3b356f88b69d01e965b8501f2ab9c712->enter($__internal_296f76f59690c2f5ddf234a9ab509f9e3b356f88b69d01e965b8501f2ab9c712_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base1.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        ";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        // line 6
        echo "       ";
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        ";
        // line 13
        $this->displayBlock('content', $context, $blocks);
        // line 15
        echo "    </body>
    ";
        // line 16
        $this->displayBlock('javascripts', $context, $blocks);
        // line 33
        echo " 
</html>
";
        
        $__internal_296f76f59690c2f5ddf234a9ab509f9e3b356f88b69d01e965b8501f2ab9c712->leave($__internal_296f76f59690c2f5ddf234a9ab509f9e3b356f88b69d01e965b8501f2ab9c712_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_574d9bc0f35f600fd4721e80500b214e4ca5e3dae53538c3c05bf08ff1c413b8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_574d9bc0f35f600fd4721e80500b214e4ca5e3dae53538c3c05bf08ff1c413b8->enter($__internal_574d9bc0f35f600fd4721e80500b214e4ca5e3dae53538c3c05bf08ff1c413b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "        ";
        
        $__internal_574d9bc0f35f600fd4721e80500b214e4ca5e3dae53538c3c05bf08ff1c413b8->leave($__internal_574d9bc0f35f600fd4721e80500b214e4ca5e3dae53538c3c05bf08ff1c413b8_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_c60e009cb5ca248bf573e3185fe440c62aa11591d96e7884e7c9de7e59a96260 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c60e009cb5ca248bf573e3185fe440c62aa11591d96e7884e7c9de7e59a96260->enter($__internal_c60e009cb5ca248bf573e3185fe440c62aa11591d96e7884e7c9de7e59a96260_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "            ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "2c8c367_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_bootstrap-datepicker_1.css");
            // line 8
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_1") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_bootstrap-select_2.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_2") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_bootstrap-theme.min_3.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_3") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_bootstrap-theme.min.css_4.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_4") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_bootstrap.min_5.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_5"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_5") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_bootstrap.min.css_6.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_6"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_6") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_font-awesome_7.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_7"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_7") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_font-awesome.min_8.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_8"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_8") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_morris_9.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_9"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_9") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_sb-admin-rtl_10.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
            // asset "2c8c367_10"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367_10") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367_part_1_sb-admin_11.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
        } else {
            // asset "2c8c367"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_2c8c367") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/2c8c367.css");
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
        }
        unset($context["asset_url"]);
        // line 10
        echo "        ";
        
        $__internal_c60e009cb5ca248bf573e3185fe440c62aa11591d96e7884e7c9de7e59a96260->leave($__internal_c60e009cb5ca248bf573e3185fe440c62aa11591d96e7884e7c9de7e59a96260_prof);

    }

    // line 13
    public function block_content($context, array $blocks = array())
    {
        $__internal_104604de87ff57219ef59e1430c57d2bd96947f3645b9fdf7735035313040b3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_104604de87ff57219ef59e1430c57d2bd96947f3645b9fdf7735035313040b3c->enter($__internal_104604de87ff57219ef59e1430c57d2bd96947f3645b9fdf7735035313040b3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 14
        echo "        ";
        
        $__internal_104604de87ff57219ef59e1430c57d2bd96947f3645b9fdf7735035313040b3c->leave($__internal_104604de87ff57219ef59e1430c57d2bd96947f3645b9fdf7735035313040b3c_prof);

    }

    // line 16
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_90f129733f3e46823c4d1863e999bcc5e4200c82e7acdae28df80cb02e29a3cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90f129733f3e46823c4d1863e999bcc5e4200c82e7acdae28df80cb02e29a3cb->enter($__internal_90f129733f3e46823c4d1863e999bcc5e4200c82e7acdae28df80cb02e29a3cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 17
        echo "            ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "6000da4_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_6000da4_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/6000da4_part_1.js");
            // line 19
            echo "                <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
            ";
        } else {
            // asset "6000da4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_6000da4") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/6000da4.js");
            echo "                <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
            ";
        }
        unset($context["asset_url"]);
        // line 21
        echo "            
            <script>
                \$(document).ready(function() {
                    \$('.datepicker').datepicker({
                        format: 'yyyy-mm-dd',
                        language: 'es',
                        autoclose: true
                    });
                    
                    \$('.selectpicker').selectpicker();
                });
            </script>
        ";
        
        $__internal_90f129733f3e46823c4d1863e999bcc5e4200c82e7acdae28df80cb02e29a3cb->leave($__internal_90f129733f3e46823c4d1863e999bcc5e4200c82e7acdae28df80cb02e29a3cb_prof);

    }

    public function getTemplateName()
    {
        return "base1.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  199 => 21,  185 => 19,  180 => 17,  174 => 16,  167 => 14,  161 => 13,  154 => 10,  80 => 8,  75 => 7,  69 => 6,  62 => 5,  56 => 4,  47 => 33,  45 => 16,  42 => 15,  40 => 13,  36 => 11,  33 => 6,  31 => 4,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        {% block title %}
        {% endblock title %}
       {% block stylesheets %}
            {% stylesheets 'bundles/app/css/*' filter='cssrewrite' %}
                <link rel=\"stylesheet\" href=\"{{ asset_url }}\" />
            {% endstylesheets %}
        {% endblock %}
    </head>
    <body>
        {% block content %}
        {% endblock content %}
    </body>
    {% block javascripts %}
            {% javascripts 
                '@jquery_and_ui' %}
                <script src=\"{{ asset_url }}\"></script>
            {% endjavascripts %}
            
            <script>
                \$(document).ready(function() {
                    \$('.datepicker').datepicker({
                        format: 'yyyy-mm-dd',
                        language: 'es',
                        autoclose: true
                    });
                    
                    \$('.selectpicker').selectpicker();
                });
            </script>
        {% endblock %} 
</html>
", "base1.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\app\\Resources\\views\\base1.html.twig");
    }
}
