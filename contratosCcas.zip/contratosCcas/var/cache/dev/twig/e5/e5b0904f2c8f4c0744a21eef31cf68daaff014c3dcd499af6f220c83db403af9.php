<?php

/* parametros/index.html.twig */
class __TwigTemplate_7ba3671aa1d944e76ea126d389a2a205acf8a78b8bc36644f9d1f2596127b8f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base1.html.twig", "parametros/index.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d488e06aec5fa29defc04091173f4b1b10396b95cda6a17783acccb21d00f35c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d488e06aec5fa29defc04091173f4b1b10396b95cda6a17783acccb21d00f35c->enter($__internal_d488e06aec5fa29defc04091173f4b1b10396b95cda6a17783acccb21d00f35c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "parametros/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d488e06aec5fa29defc04091173f4b1b10396b95cda6a17783acccb21d00f35c->leave($__internal_d488e06aec5fa29defc04091173f4b1b10396b95cda6a17783acccb21d00f35c_prof);

    }

    // line 2
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_7134c10108eaca8f0609739af69070d3d36d55e2f387fc9b1473b4e2e8820ba5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7134c10108eaca8f0609739af69070d3d36d55e2f387fc9b1473b4e2e8820ba5->enter($__internal_7134c10108eaca8f0609739af69070d3d36d55e2f387fc9b1473b4e2e8820ba5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 3
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    ";
        // line 4
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "9d3a176_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_9d3a176_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/9d3a176_part_1_buttons.dataTables.min_1.css");
            // line 5
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
            // asset "9d3a176_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_9d3a176_1") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/9d3a176_part_1_dataTableCustom_2.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
            // asset "9d3a176_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_9d3a176_2") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/9d3a176_part_1_dataTables.bootstrap_3.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        } else {
            // asset "9d3a176"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_9d3a176") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/9d3a176.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        }
        unset($context["asset_url"]);
        
        $__internal_7134c10108eaca8f0609739af69070d3d36d55e2f387fc9b1473b4e2e8820ba5->leave($__internal_7134c10108eaca8f0609739af69070d3d36d55e2f387fc9b1473b4e2e8820ba5_prof);

    }

    // line 8
    public function block_content($context, array $blocks = array())
    {
        $__internal_242970a11ccd832600e752e6523458d3974dd35bdbe33a6d90a4b916ec1b8b20 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_242970a11ccd832600e752e6523458d3974dd35bdbe33a6d90a4b916ec1b8b20->enter($__internal_242970a11ccd832600e752e6523458d3974dd35bdbe33a6d90a4b916ec1b8b20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 9
        echo "    <div class=\"container\">
        <div class=\"panel panel-info\">
            <div class=\"panel-heading\">
                 <h2><span class=\"glyphicon glyphicon-tags\" aria-hidden=\"true\"></span> Parametros</h2>
            </div>
            <div class=\"panel-body table-responsive\" id=\"tabla_matriculados\" style=\"width:100%;\" >  
                <div class=\"col-md-12\">
                    <a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("parametros_new");
        echo "\" class=\"btn btn-primary pull-right\" >Nuevo Parametro</a>
                </div>
                <table id=\"listParametros\" class=\"table table-striped table-bordered table-condensed table-hover \" cellspacing=\"0\" width=\"100%\">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Descripción</th>
                            <th>Creado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["parametros"]) ? $context["parametros"] : $this->getContext($context, "parametros")));
        foreach ($context['_seq'] as $context["_key"] => $context["parametro"]) {
            // line 29
            echo "                        <tr>
                            <td><a href=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("parametros_show", array("id" => $this->getAttribute($context["parametro"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["parametro"], "id", array()), "html", null, true);
            echo "</a></td>
                            <td>";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["parametro"], "descripcion", array()), "html", null, true);
            echo "</td>
                            <td>";
            // line 32
            if ($this->getAttribute($context["parametro"], "current", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["parametro"], "current", array()), "Y-m-d"), "html", null, true);
            }
            echo "</td>
                            <td>
                                <a href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("parametros_edit", array("id" => $this->getAttribute($context["parametro"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-primary\" >Editar</a>         
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['parametro'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "                    </tbody>
                </table>
             </div>
         </div>
    </div>
    
";
        
        $__internal_242970a11ccd832600e752e6523458d3974dd35bdbe33a6d90a4b916ec1b8b20->leave($__internal_242970a11ccd832600e752e6523458d3974dd35bdbe33a6d90a4b916ec1b8b20_prof);

    }

    // line 45
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_9af75c8b686669ae67f1e9f883ef705358249210a01f99a0b8f5622ce20a8b4a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9af75c8b686669ae67f1e9f883ef705358249210a01f99a0b8f5622ce20a8b4a->enter($__internal_9af75c8b686669ae67f1e9f883ef705358249210a01f99a0b8f5622ce20a8b4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 46
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    ";
        // line 47
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "52788c5_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5_part_1_blockUI_1.js");
            // line 49
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "52788c5_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5_1") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5_part_1_buttons.flash.min_2.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "52788c5_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5_2") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5_part_1_buttons.html5.min_3.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "52788c5_3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5_3") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5_part_1_buttons.print.min_4.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "52788c5_4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5_4") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5_part_1_dataTables.bootstrap_5.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "52788c5_5"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5_5") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5_part_1_dataTables.bootstrap.min_6.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "52788c5_6"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5_6") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5_part_1_dataTables.buttons.min_7.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "52788c5_7"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5_7") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5_part_1_jquery-1.12.4_8.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "52788c5_8"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5_8") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5_part_1_jquery.dataTables_9.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "52788c5_9"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5_9") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5_part_1_jquery.dataTables.min_10.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "52788c5_10"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5_10") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5_part_1_jszip.min_11.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "52788c5_11"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5_11") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5_part_1_pdfmake.min_12.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "52788c5_12"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5_12") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5_part_1_vfs_fonts_13.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
        } else {
            // asset "52788c5"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_52788c5") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/52788c5.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
        }
        unset($context["asset_url"]);
        // line 51
        echo "    <script>
        \$(document).ready(function(){
            var table = \$('#listParametros').DataTable();
        });
    </script>
    
";
        
        $__internal_9af75c8b686669ae67f1e9f883ef705358249210a01f99a0b8f5622ce20a8b4a->leave($__internal_9af75c8b686669ae67f1e9f883ef705358249210a01f99a0b8f5622ce20a8b4a_prof);

    }

    public function getTemplateName()
    {
        return "parametros/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  260 => 51,  174 => 49,  170 => 47,  165 => 46,  159 => 45,  146 => 38,  136 => 34,  129 => 32,  125 => 31,  119 => 30,  116 => 29,  112 => 28,  97 => 16,  88 => 9,  82 => 8,  51 => 5,  47 => 4,  42 => 3,  36 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base1.html.twig' %}
{% block stylesheets %}
    {{ parent() }}
    {% stylesheets 'bundles/app/datatable/css/*' filter='cssrewrite' %}
        <link rel=\"stylesheet\" href=\"{{ asset_url }}\" />
    {% endstylesheets %}
{% endblock %}
{% block content %}
    <div class=\"container\">
        <div class=\"panel panel-info\">
            <div class=\"panel-heading\">
                 <h2><span class=\"glyphicon glyphicon-tags\" aria-hidden=\"true\"></span> Parametros</h2>
            </div>
            <div class=\"panel-body table-responsive\" id=\"tabla_matriculados\" style=\"width:100%;\" >  
                <div class=\"col-md-12\">
                    <a href=\"{{ path('parametros_new') }}\" class=\"btn btn-primary pull-right\" >Nuevo Parametro</a>
                </div>
                <table id=\"listParametros\" class=\"table table-striped table-bordered table-condensed table-hover \" cellspacing=\"0\" width=\"100%\">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Descripción</th>
                            <th>Creado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    {% for parametro in parametros %}
                        <tr>
                            <td><a href=\"{{ path('parametros_show', { 'id': parametro.id }) }}\">{{ parametro.id }}</a></td>
                            <td>{{ parametro.descripcion }}</td>
                            <td>{% if parametro.current %}{{ parametro.current|date('Y-m-d') }}{% endif %}</td>
                            <td>
                                <a href=\"{{ path('parametros_edit', { 'id': parametro.id }) }}\" class=\"btn btn-primary\" >Editar</a>         
                            </td>
                        </tr>
                    {% endfor %}
                    </tbody>
                </table>
             </div>
         </div>
    </div>
    
{% endblock content %}
{% block javascripts %}
    {{ parent() }}
    {% javascripts 
        '@AppBundle/Resources/public/datatable/js/*' %}
        <script src=\"{{ asset_url }}\"></script>
    {% endjavascripts %}
    <script>
        \$(document).ready(function(){
            var table = \$('#listParametros').DataTable();
        });
    </script>
    
{% endblock javascripts %}    
", "parametros/index.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\app\\Resources\\views\\parametros\\index.html.twig");
    }
}
