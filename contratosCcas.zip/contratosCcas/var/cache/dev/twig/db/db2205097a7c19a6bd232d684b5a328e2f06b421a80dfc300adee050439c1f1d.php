<?php

/* parametros/new.html.twig */
class __TwigTemplate_fad05b799d1e061795be34ab0360c8c81c408b8c3dbd0bcd4e595c0b9d51b7cf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base1.html.twig", "parametros/new.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3c520dc35ae2f1ab3f5a0ada13e8aba0d69ed1508d65001bba4d371043b82525 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c520dc35ae2f1ab3f5a0ada13e8aba0d69ed1508d65001bba4d371043b82525->enter($__internal_3c520dc35ae2f1ab3f5a0ada13e8aba0d69ed1508d65001bba4d371043b82525_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "parametros/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3c520dc35ae2f1ab3f5a0ada13e8aba0d69ed1508d65001bba4d371043b82525->leave($__internal_3c520dc35ae2f1ab3f5a0ada13e8aba0d69ed1508d65001bba4d371043b82525_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_fe35f6f143628a30441e38c6843caf7ecd3570c7b65c1ce6466524c70014c283 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe35f6f143628a30441e38c6843caf7ecd3570c7b65c1ce6466524c70014c283->enter($__internal_fe35f6f143628a30441e38c6843caf7ecd3570c7b65c1ce6466524c70014c283_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <div class=\"container\">
        
        <h2><span class=\"glyphicon glyphicon-tags\" aria-hidden=\"true\"></span> Crear Parametro</h2>
        ";
        // line 7
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
          <div class=\"form-group\">
            ";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "descripcion", array()), 'label');
        echo "
            ";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "descripcion", array()), 'widget');
        echo "
          </div>
          
          <div class=\"form-group\">
            ";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipoParametro", array()), 'label');
        echo "
            ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tipoParametro", array()), 'widget');
        echo "
          </div>
          <div class=\"form-group\">
            ";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "current", array()), 'label');
        echo "
            ";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "current", array()), 'widget');
        echo "
          </div> 
          <div class=\"form-group\">
            ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "save", array()), 'widget');
        echo "
          </div>
          
        ";
        // line 25
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    </div>
";
        
        $__internal_fe35f6f143628a30441e38c6843caf7ecd3570c7b65c1ce6466524c70014c283->leave($__internal_fe35f6f143628a30441e38c6843caf7ecd3570c7b65c1ce6466524c70014c283_prof);

    }

    public function getTemplateName()
    {
        return "parametros/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 25,  81 => 22,  75 => 19,  71 => 18,  65 => 15,  61 => 14,  54 => 10,  50 => 9,  45 => 7,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base1.html.twig' %}

{% block content %}
    <div class=\"container\">
        
        <h2><span class=\"glyphicon glyphicon-tags\" aria-hidden=\"true\"></span> Crear Parametro</h2>
        {{ form_start(form) }}
          <div class=\"form-group\">
            {{ form_label(form.descripcion) }}
            {{ form_widget(form.descripcion) }}
          </div>
          
          <div class=\"form-group\">
            {{ form_label(form.tipoParametro) }}
            {{ form_widget(form.tipoParametro) }}
          </div>
          <div class=\"form-group\">
            {{ form_label(form.current) }}
            {{ form_widget(form.current) }}
          </div> 
          <div class=\"form-group\">
            {{ form_widget(form.save) }}
          </div>
          
        {{ form_end(form) }}
    </div>
{% endblock content%}
", "parametros/new.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\app\\Resources\\views\\parametros\\new.html.twig");
    }
}
