<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_cfb0d17fa766529c2767b427b7c7aeb9d219d0dc0e13e80639da6514333c77c9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c711e45799bba6c81112e2192a72a5c25567a9a94adceef9ec8cf25dbc79b944 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c711e45799bba6c81112e2192a72a5c25567a9a94adceef9ec8cf25dbc79b944->enter($__internal_c711e45799bba6c81112e2192a72a5c25567a9a94adceef9ec8cf25dbc79b944_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_c711e45799bba6c81112e2192a72a5c25567a9a94adceef9ec8cf25dbc79b944->leave($__internal_c711e45799bba6c81112e2192a72a5c25567a9a94adceef9ec8cf25dbc79b944_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
