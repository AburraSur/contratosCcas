<?php

/* @FOSUser/ChangePassword/change_password.html.twig */
class __TwigTemplate_c646fda2b2e979b35416cf42bb71a8920c72d8790713a805e6dcb6ecfa6be2b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/ChangePassword/change_password.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7c117f09a94d041f54948a90e4c425045d8b317b1c5189ac3a3d15a92e0157bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c117f09a94d041f54948a90e4c425045d8b317b1c5189ac3a3d15a92e0157bd->enter($__internal_7c117f09a94d041f54948a90e4c425045d8b317b1c5189ac3a3d15a92e0157bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/ChangePassword/change_password.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7c117f09a94d041f54948a90e4c425045d8b317b1c5189ac3a3d15a92e0157bd->leave($__internal_7c117f09a94d041f54948a90e4c425045d8b317b1c5189ac3a3d15a92e0157bd_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_18bc11afec5628bbdbc3d2ea38880859442227abd8c3404b4d9e48fdb2748b44 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18bc11afec5628bbdbc3d2ea38880859442227abd8c3404b4d9e48fdb2748b44->enter($__internal_18bc11afec5628bbdbc3d2ea38880859442227abd8c3404b4d9e48fdb2748b44_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/ChangePassword/change_password_content.html.twig", "@FOSUser/ChangePassword/change_password.html.twig", 4)->display($context);
        
        $__internal_18bc11afec5628bbdbc3d2ea38880859442227abd8c3404b4d9e48fdb2748b44->leave($__internal_18bc11afec5628bbdbc3d2ea38880859442227abd8c3404b4d9e48fdb2748b44_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/ChangePassword/change_password.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/ChangePassword/change_password_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/ChangePassword/change_password.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\ChangePassword\\change_password.html.twig");
    }
}
