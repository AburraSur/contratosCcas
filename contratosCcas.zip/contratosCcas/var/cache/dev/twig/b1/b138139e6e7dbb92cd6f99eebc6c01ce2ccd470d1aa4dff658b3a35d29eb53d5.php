<?php

/* @FOSUser/Security/login.html.twig */
class __TwigTemplate_cf226d54af9e36d3db24c478053378beee60d07213f70c60429bb0f8a2b2a30f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Security/login.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6aaf90538bf18394ba26dbd339f5f6aab004f2b3414dc672571655443ae4f9d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6aaf90538bf18394ba26dbd339f5f6aab004f2b3414dc672571655443ae4f9d3->enter($__internal_6aaf90538bf18394ba26dbd339f5f6aab004f2b3414dc672571655443ae4f9d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6aaf90538bf18394ba26dbd339f5f6aab004f2b3414dc672571655443ae4f9d3->leave($__internal_6aaf90538bf18394ba26dbd339f5f6aab004f2b3414dc672571655443ae4f9d3_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_8d1978ce3884427890a742f8f9211838a395d92540cbd105039f51a4573f07c6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d1978ce3884427890a742f8f9211838a395d92540cbd105039f51a4573f07c6->enter($__internal_8d1978ce3884427890a742f8f9211838a395d92540cbd105039f51a4573f07c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        echo "    ";
        echo twig_include($this->env, $context, "@FOSUser/Security/login_content.html.twig");
        echo "
";
        
        $__internal_8d1978ce3884427890a742f8f9211838a395d92540cbd105039f51a4573f07c6->leave($__internal_8d1978ce3884427890a742f8f9211838a395d92540cbd105039f51a4573f07c6_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
    {{ include('@FOSUser/Security/login_content.html.twig') }}
{% endblock fos_user_content %}
", "@FOSUser/Security/login.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Security\\login.html.twig");
    }
}
