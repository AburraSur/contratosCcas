<?php

/* @FOSUser/Resetting/reset.html.twig */
class __TwigTemplate_1e034ea5811a10e6ce7810576db2e1d8e3f4da62a4da1850f10706327635941d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Resetting/reset.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_940d238c691af0ddc8bc0a5d90e584661e4f14b5c84f04d455ae9de0e09b0521 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_940d238c691af0ddc8bc0a5d90e584661e4f14b5c84f04d455ae9de0e09b0521->enter($__internal_940d238c691af0ddc8bc0a5d90e584661e4f14b5c84f04d455ae9de0e09b0521_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Resetting/reset.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_940d238c691af0ddc8bc0a5d90e584661e4f14b5c84f04d455ae9de0e09b0521->leave($__internal_940d238c691af0ddc8bc0a5d90e584661e4f14b5c84f04d455ae9de0e09b0521_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_c392df1c62c1ee2728e52fd43db09157341ce62a14d9af47e330830676cfbb15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c392df1c62c1ee2728e52fd43db09157341ce62a14d9af47e330830676cfbb15->enter($__internal_c392df1c62c1ee2728e52fd43db09157341ce62a14d9af47e330830676cfbb15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Resetting/reset_content.html.twig", "@FOSUser/Resetting/reset.html.twig", 4)->display($context);
        
        $__internal_c392df1c62c1ee2728e52fd43db09157341ce62a14d9af47e330830676cfbb15->leave($__internal_c392df1c62c1ee2728e52fd43db09157341ce62a14d9af47e330830676cfbb15_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Resetting/reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Resetting/reset_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Resetting/reset.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Resetting\\reset.html.twig");
    }
}
