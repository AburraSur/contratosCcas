<?php

/* ::base.html.twig */
class __TwigTemplate_e0ceec297fe2e6a9473ad06fec8e381147776b01caa29fe38ff6d0e5e151e539 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_429a84d914a17e99081717b1acd5f37e577707d381a7abaa3973ace070b4b417 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_429a84d914a17e99081717b1acd5f37e577707d381a7abaa3973ace070b4b417->enter($__internal_429a84d914a17e99081717b1acd5f37e577707d381a7abaa3973ace070b4b417_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_429a84d914a17e99081717b1acd5f37e577707d381a7abaa3973ace070b4b417->leave($__internal_429a84d914a17e99081717b1acd5f37e577707d381a7abaa3973ace070b4b417_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_66df791b3722174aac087fbbd81f0c2f5fd7632507215ca2e325b32088409b64 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66df791b3722174aac087fbbd81f0c2f5fd7632507215ca2e325b32088409b64->enter($__internal_66df791b3722174aac087fbbd81f0c2f5fd7632507215ca2e325b32088409b64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_66df791b3722174aac087fbbd81f0c2f5fd7632507215ca2e325b32088409b64->leave($__internal_66df791b3722174aac087fbbd81f0c2f5fd7632507215ca2e325b32088409b64_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_1ffaa69b18bf27e90a4d047937207fdc740a63bfa156357132753db969fc431e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1ffaa69b18bf27e90a4d047937207fdc740a63bfa156357132753db969fc431e->enter($__internal_1ffaa69b18bf27e90a4d047937207fdc740a63bfa156357132753db969fc431e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_1ffaa69b18bf27e90a4d047937207fdc740a63bfa156357132753db969fc431e->leave($__internal_1ffaa69b18bf27e90a4d047937207fdc740a63bfa156357132753db969fc431e_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_528902c8d8c7ea6ea2e052c5ead965858815f49f77f1c54f8cf6ebcf377f0d67 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_528902c8d8c7ea6ea2e052c5ead965858815f49f77f1c54f8cf6ebcf377f0d67->enter($__internal_528902c8d8c7ea6ea2e052c5ead965858815f49f77f1c54f8cf6ebcf377f0d67_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_528902c8d8c7ea6ea2e052c5ead965858815f49f77f1c54f8cf6ebcf377f0d67->leave($__internal_528902c8d8c7ea6ea2e052c5ead965858815f49f77f1c54f8cf6ebcf377f0d67_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_67af3ab69713154462685359dec08db0c8af845016defb89e14af97ad18c88f5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_67af3ab69713154462685359dec08db0c8af845016defb89e14af97ad18c88f5->enter($__internal_67af3ab69713154462685359dec08db0c8af845016defb89e14af97ad18c88f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_67af3ab69713154462685359dec08db0c8af845016defb89e14af97ad18c88f5->leave($__internal_67af3ab69713154462685359dec08db0c8af845016defb89e14af97ad18c88f5_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\app/Resources\\views/base.html.twig");
    }
}
