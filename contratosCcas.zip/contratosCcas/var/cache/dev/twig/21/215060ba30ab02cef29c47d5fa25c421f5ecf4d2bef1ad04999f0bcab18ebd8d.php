<?php

/* @FOSUser/Group/new.html.twig */
class __TwigTemplate_80cbe5b8dbdcef52b271cbf1a52c12e4cb2b061cae784285c3feea14b5fd7636 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Group/new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bf15ec43a1c67777f4e48961c7d4a05d02b1a8784d2f36fd2c0fd8e93692d6e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf15ec43a1c67777f4e48961c7d4a05d02b1a8784d2f36fd2c0fd8e93692d6e6->enter($__internal_bf15ec43a1c67777f4e48961c7d4a05d02b1a8784d2f36fd2c0fd8e93692d6e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Group/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bf15ec43a1c67777f4e48961c7d4a05d02b1a8784d2f36fd2c0fd8e93692d6e6->leave($__internal_bf15ec43a1c67777f4e48961c7d4a05d02b1a8784d2f36fd2c0fd8e93692d6e6_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_d3dc59a89d3e7dbf0a7e28db5c92e57ac466ca5e356820683f89dff2a19775e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d3dc59a89d3e7dbf0a7e28db5c92e57ac466ca5e356820683f89dff2a19775e7->enter($__internal_d3dc59a89d3e7dbf0a7e28db5c92e57ac466ca5e356820683f89dff2a19775e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/new_content.html.twig", "@FOSUser/Group/new.html.twig", 4)->display($context);
        
        $__internal_d3dc59a89d3e7dbf0a7e28db5c92e57ac466ca5e356820683f89dff2a19775e7->leave($__internal_d3dc59a89d3e7dbf0a7e28db5c92e57ac466ca5e356820683f89dff2a19775e7_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Group/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/new_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Group/new.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Group\\new.html.twig");
    }
}
