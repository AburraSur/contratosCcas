<?php

/* base.html.twig */
class __TwigTemplate_6e2b0d25e234e8d89485a3ad1e036c4998ee32c216a7a9964c960e2c0ed27c7b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_083ddaf7e13963e3454ca79776177fd05fc678ace063af12eab529c889833099 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_083ddaf7e13963e3454ca79776177fd05fc678ace063af12eab529c889833099->enter($__internal_083ddaf7e13963e3454ca79776177fd05fc678ace063af12eab529c889833099_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_083ddaf7e13963e3454ca79776177fd05fc678ace063af12eab529c889833099->leave($__internal_083ddaf7e13963e3454ca79776177fd05fc678ace063af12eab529c889833099_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_15166639e98ce124dd052c4291122b56977a2275cd8b67f8f2d477db3f9f0ef9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_15166639e98ce124dd052c4291122b56977a2275cd8b67f8f2d477db3f9f0ef9->enter($__internal_15166639e98ce124dd052c4291122b56977a2275cd8b67f8f2d477db3f9f0ef9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_15166639e98ce124dd052c4291122b56977a2275cd8b67f8f2d477db3f9f0ef9->leave($__internal_15166639e98ce124dd052c4291122b56977a2275cd8b67f8f2d477db3f9f0ef9_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ad9f90a090a7cdf9d8eef29ce07dabc84b93de36db705b523fc5cfabfcd04160 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad9f90a090a7cdf9d8eef29ce07dabc84b93de36db705b523fc5cfabfcd04160->enter($__internal_ad9f90a090a7cdf9d8eef29ce07dabc84b93de36db705b523fc5cfabfcd04160_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_ad9f90a090a7cdf9d8eef29ce07dabc84b93de36db705b523fc5cfabfcd04160->leave($__internal_ad9f90a090a7cdf9d8eef29ce07dabc84b93de36db705b523fc5cfabfcd04160_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_18768391efc8ae05a3ed6d40d1fee1f8a06c3886a633b6636b34d866df9d4c34 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18768391efc8ae05a3ed6d40d1fee1f8a06c3886a633b6636b34d866df9d4c34->enter($__internal_18768391efc8ae05a3ed6d40d1fee1f8a06c3886a633b6636b34d866df9d4c34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_18768391efc8ae05a3ed6d40d1fee1f8a06c3886a633b6636b34d866df9d4c34->leave($__internal_18768391efc8ae05a3ed6d40d1fee1f8a06c3886a633b6636b34d866df9d4c34_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_901bf62772d79accb780d644eadfb4be6c220fab28fbbd216fcf6bf45a62cea4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_901bf62772d79accb780d644eadfb4be6c220fab28fbbd216fcf6bf45a62cea4->enter($__internal_901bf62772d79accb780d644eadfb4be6c220fab28fbbd216fcf6bf45a62cea4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_901bf62772d79accb780d644eadfb4be6c220fab28fbbd216fcf6bf45a62cea4->leave($__internal_901bf62772d79accb780d644eadfb4be6c220fab28fbbd216fcf6bf45a62cea4_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\app\\Resources\\views\\base.html.twig");
    }
}
