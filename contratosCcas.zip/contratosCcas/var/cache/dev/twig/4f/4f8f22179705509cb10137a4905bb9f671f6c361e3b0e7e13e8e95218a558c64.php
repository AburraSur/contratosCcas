<?php

/* FOSUserBundle:Group:new.html.twig */
class __TwigTemplate_d1acb3e14dbd6c8370a130912036e4699bce679d71ce24f7fa5804a6f89d91dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_27e8d1ea747295e5e5ea84204a0790467c4a779406380a8548595dbae301c553 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27e8d1ea747295e5e5ea84204a0790467c4a779406380a8548595dbae301c553->enter($__internal_27e8d1ea747295e5e5ea84204a0790467c4a779406380a8548595dbae301c553_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_27e8d1ea747295e5e5ea84204a0790467c4a779406380a8548595dbae301c553->leave($__internal_27e8d1ea747295e5e5ea84204a0790467c4a779406380a8548595dbae301c553_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f9ce74dc42f1ce03b995f66d2055851d98554e885f800aae2fd728d4912ab58a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9ce74dc42f1ce03b995f66d2055851d98554e885f800aae2fd728d4912ab58a->enter($__internal_f9ce74dc42f1ce03b995f66d2055851d98554e885f800aae2fd728d4912ab58a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/new_content.html.twig", "FOSUserBundle:Group:new.html.twig", 4)->display($context);
        
        $__internal_f9ce74dc42f1ce03b995f66d2055851d98554e885f800aae2fd728d4912ab58a->leave($__internal_f9ce74dc42f1ce03b995f66d2055851d98554e885f800aae2fd728d4912ab58a_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/new_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:new.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle/Resources/views/Group/new.html.twig");
    }
}
