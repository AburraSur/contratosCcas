<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_6439fc97803c153f65e42e1f9301a22300b6562f07778aa9f23c22dde3912fdd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_757c774c6bd53e080df448d2497cce0fdad2c8b87da9d0c3a2267a113fec5cf0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_757c774c6bd53e080df448d2497cce0fdad2c8b87da9d0c3a2267a113fec5cf0->enter($__internal_757c774c6bd53e080df448d2497cce0fdad2c8b87da9d0c3a2267a113fec5cf0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_757c774c6bd53e080df448d2497cce0fdad2c8b87da9d0c3a2267a113fec5cf0->leave($__internal_757c774c6bd53e080df448d2497cce0fdad2c8b87da9d0c3a2267a113fec5cf0_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_ccf315ef9ebda1ef7e3ce180d134a87e86b4bdf4181a86e3e195f85f526bd270 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ccf315ef9ebda1ef7e3ce180d134a87e86b4bdf4181a86e3e195f85f526bd270->enter($__internal_ccf315ef9ebda1ef7e3ce180d134a87e86b4bdf4181a86e3e195f85f526bd270_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_ccf315ef9ebda1ef7e3ce180d134a87e86b4bdf4181a86e3e195f85f526bd270->leave($__internal_ccf315ef9ebda1ef7e3ce180d134a87e86b4bdf4181a86e3e195f85f526bd270_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
