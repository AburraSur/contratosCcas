<?php

/* :parametros:show.html.twig */
class __TwigTemplate_7a43a841509d59cb9462d37563da1eac18cf310899f7de996ac12c3191d0af4a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":parametros:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bfca484d51edc122d1a1898984998005b54fcec8e0be6992e19c8c4d87c07a88 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bfca484d51edc122d1a1898984998005b54fcec8e0be6992e19c8c4d87c07a88->enter($__internal_bfca484d51edc122d1a1898984998005b54fcec8e0be6992e19c8c4d87c07a88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":parametros:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bfca484d51edc122d1a1898984998005b54fcec8e0be6992e19c8c4d87c07a88->leave($__internal_bfca484d51edc122d1a1898984998005b54fcec8e0be6992e19c8c4d87c07a88_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_6e10849cc91b710715be8f3b5bed3394712877229900a49aa930ab0bcb098f5a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6e10849cc91b710715be8f3b5bed3394712877229900a49aa930ab0bcb098f5a->enter($__internal_6e10849cc91b710715be8f3b5bed3394712877229900a49aa930ab0bcb098f5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Parametro</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["parametro"]) ? $context["parametro"] : $this->getContext($context, "parametro")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Descripcion</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["parametro"]) ? $context["parametro"] : $this->getContext($context, "parametro")), "descripcion", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Current</th>
                <td>";
        // line 18
        if ($this->getAttribute((isset($context["parametro"]) ? $context["parametro"] : $this->getContext($context, "parametro")), "current", array())) {
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["parametro"]) ? $context["parametro"] : $this->getContext($context, "parametro")), "current", array()), "Y-m-d"), "html", null, true);
        }
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("parametros_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            <a href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("parametros_edit", array("id" => $this->getAttribute((isset($context["parametro"]) ? $context["parametro"] : $this->getContext($context, "parametro")), "id", array()))), "html", null, true);
        echo "\">Edit</a>
        </li>
        <li>
            ";
        // line 31
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 33
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_6e10849cc91b710715be8f3b5bed3394712877229900a49aa930ab0bcb098f5a->leave($__internal_6e10849cc91b710715be8f3b5bed3394712877229900a49aa930ab0bcb098f5a_prof);

    }

    public function getTemplateName()
    {
        return ":parametros:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 33,  86 => 31,  80 => 28,  74 => 25,  62 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Parametro</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ parametro.id }}</td>
            </tr>
            <tr>
                <th>Descripcion</th>
                <td>{{ parametro.descripcion }}</td>
            </tr>
            <tr>
                <th>Current</th>
                <td>{% if parametro.current %}{{ parametro.current|date('Y-m-d') }}{% endif %}</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('parametros_index') }}\">Back to the list</a>
        </li>
        <li>
            <a href=\"{{ path('parametros_edit', { 'id': parametro.id }) }}\">Edit</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", ":parametros:show.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\app/Resources\\views/parametros/show.html.twig");
    }
}
