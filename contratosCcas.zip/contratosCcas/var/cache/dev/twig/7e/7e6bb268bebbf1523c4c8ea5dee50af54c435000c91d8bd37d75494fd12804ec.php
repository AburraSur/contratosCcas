<?php

/* :tipoparametro:index.html.twig */
class __TwigTemplate_e18dcea13afa0f0dc42126aa8c260c5c520e6b1683c67ce24540b434756e7d2c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":tipoparametro:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a69d4e0890b2ef63156c7c2a7d8b73631b4961f2fab9d02cc8249f8f20a41f3a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a69d4e0890b2ef63156c7c2a7d8b73631b4961f2fab9d02cc8249f8f20a41f3a->enter($__internal_a69d4e0890b2ef63156c7c2a7d8b73631b4961f2fab9d02cc8249f8f20a41f3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":tipoparametro:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a69d4e0890b2ef63156c7c2a7d8b73631b4961f2fab9d02cc8249f8f20a41f3a->leave($__internal_a69d4e0890b2ef63156c7c2a7d8b73631b4961f2fab9d02cc8249f8f20a41f3a_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_cadb78b0ba727db869326b20b7d5ce9235fd11fbcaa7fc5bc1b40248e978a6fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cadb78b0ba727db869326b20b7d5ce9235fd11fbcaa7fc5bc1b40248e978a6fe->enter($__internal_cadb78b0ba727db869326b20b7d5ce9235fd11fbcaa7fc5bc1b40248e978a6fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Tipoparametros list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Parametro</th>
                <th>Current</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tipoParametros"]) ? $context["tipoParametros"] : $this->getContext($context, "tipoParametros")));
        foreach ($context['_seq'] as $context["_key"] => $context["tipoParametro"]) {
            // line 17
            echo "            <tr>
                <td><a href=\"";
            // line 18
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("tipoparametro_show", array("id" => $this->getAttribute($context["tipoParametro"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["tipoParametro"], "id", array()), "html", null, true);
            echo "</a></td>
                <td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["tipoParametro"], "parametro", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 20
            if ($this->getAttribute($context["tipoParametro"], "current", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["tipoParametro"], "current", array()), "Y-m-d"), "html", null, true);
            }
            echo "</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("tipoparametro_show", array("id" => $this->getAttribute($context["tipoParametro"], "id", array()))), "html", null, true);
            echo "\">show</a>
                        </li>
                        <li>
                            <a href=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("tipoparametro_edit", array("id" => $this->getAttribute($context["tipoParametro"], "id", array()))), "html", null, true);
            echo "\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tipoParametro'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("tipoparametro_new");
        echo "\">Create a new tipoParametro</a>
        </li>
    </ul>
";
        
        $__internal_cadb78b0ba727db869326b20b7d5ce9235fd11fbcaa7fc5bc1b40248e978a6fe->leave($__internal_cadb78b0ba727db869326b20b7d5ce9235fd11fbcaa7fc5bc1b40248e978a6fe_prof);

    }

    public function getTemplateName()
    {
        return ":tipoparametro:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 38,  98 => 33,  86 => 27,  80 => 24,  71 => 20,  67 => 19,  61 => 18,  58 => 17,  54 => 16,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Tipoparametros list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Parametro</th>
                <th>Current</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        {% for tipoParametro in tipoParametros %}
            <tr>
                <td><a href=\"{{ path('tipoparametro_show', { 'id': tipoParametro.id }) }}\">{{ tipoParametro.id }}</a></td>
                <td>{{ tipoParametro.parametro }}</td>
                <td>{% if tipoParametro.current %}{{ tipoParametro.current|date('Y-m-d') }}{% endif %}</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"{{ path('tipoparametro_show', { 'id': tipoParametro.id }) }}\">show</a>
                        </li>
                        <li>
                            <a href=\"{{ path('tipoparametro_edit', { 'id': tipoParametro.id }) }}\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('tipoparametro_new') }}\">Create a new tipoParametro</a>
        </li>
    </ul>
{% endblock %}
", ":tipoparametro:index.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\app/Resources\\views/tipoparametro/index.html.twig");
    }
}
