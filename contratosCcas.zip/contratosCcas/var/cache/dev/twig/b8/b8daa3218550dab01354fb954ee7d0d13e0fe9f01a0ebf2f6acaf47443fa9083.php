<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_c6383520029e52e75827f0230a46737c69dbb54d5e748c518df6d969423ec025 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_05c1cd16dc913a389b90432c917f2ecc2a2f960a3b61c45848ecb122b83b36c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05c1cd16dc913a389b90432c917f2ecc2a2f960a3b61c45848ecb122b83b36c9->enter($__internal_05c1cd16dc913a389b90432c917f2ecc2a2f960a3b61c45848ecb122b83b36c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_05c1cd16dc913a389b90432c917f2ecc2a2f960a3b61c45848ecb122b83b36c9->leave($__internal_05c1cd16dc913a389b90432c917f2ecc2a2f960a3b61c45848ecb122b83b36c9_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
