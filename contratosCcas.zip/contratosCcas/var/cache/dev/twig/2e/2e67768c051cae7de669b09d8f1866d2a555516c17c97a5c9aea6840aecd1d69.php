<?php

/* FOSUserBundle:Resetting:check_email.html.twig */
class __TwigTemplate_ab5808166b67e8e644969d38c5425fbf7197cacc8b7ee5be99cd6a31f264a030 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:check_email.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6b85ee09b9844ca13a9830f8237cdf535aad8034c738b6e6bca6a9f90f851344 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b85ee09b9844ca13a9830f8237cdf535aad8034c738b6e6bca6a9f90f851344->enter($__internal_6b85ee09b9844ca13a9830f8237cdf535aad8034c738b6e6bca6a9f90f851344_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:check_email.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6b85ee09b9844ca13a9830f8237cdf535aad8034c738b6e6bca6a9f90f851344->leave($__internal_6b85ee09b9844ca13a9830f8237cdf535aad8034c738b6e6bca6a9f90f851344_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_9feda5d17bef2d1ba092f9eec439b4ee06fea50997c81ac5f55d25af1ecd3dd8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9feda5d17bef2d1ba092f9eec439b4ee06fea50997c81ac5f55d25af1ecd3dd8->enter($__internal_9feda5d17bef2d1ba092f9eec439b4ee06fea50997c81ac5f55d25af1ecd3dd8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>
";
        // line 7
        echo nl2br(twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.check_email", array("%tokenLifetime%" => (isset($context["tokenLifetime"]) ? $context["tokenLifetime"] : $this->getContext($context, "tokenLifetime"))), "FOSUserBundle"), "html", null, true));
        echo "
</p>
";
        
        $__internal_9feda5d17bef2d1ba092f9eec439b4ee06fea50997c81ac5f55d25af1ecd3dd8->leave($__internal_9feda5d17bef2d1ba092f9eec439b4ee06fea50997c81ac5f55d25af1ecd3dd8_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:check_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 7,  40 => 6,  34 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
<p>
{{ 'resetting.check_email'|trans({'%tokenLifetime%': tokenLifetime})|nl2br }}
</p>
{% endblock %}
", "FOSUserBundle:Resetting:check_email.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle/Resources/views/Resetting/check_email.html.twig");
    }
}
