<?php

/* @FOSUser/Group/edit.html.twig */
class __TwigTemplate_5174a7c43539811630a7f84cea02ae15c6420e30ec5168f7797344b0430a7fb9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Group/edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e75ed9b6309835152fb4a1b456fddecae7ea7ce7b419f94b73bbaea1676fe77c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e75ed9b6309835152fb4a1b456fddecae7ea7ce7b419f94b73bbaea1676fe77c->enter($__internal_e75ed9b6309835152fb4a1b456fddecae7ea7ce7b419f94b73bbaea1676fe77c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Group/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e75ed9b6309835152fb4a1b456fddecae7ea7ce7b419f94b73bbaea1676fe77c->leave($__internal_e75ed9b6309835152fb4a1b456fddecae7ea7ce7b419f94b73bbaea1676fe77c_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_c480d98ab745e9f67efc41c2dd0407220ab1cda3f34bd80afa5b7d7f465433c7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c480d98ab745e9f67efc41c2dd0407220ab1cda3f34bd80afa5b7d7f465433c7->enter($__internal_c480d98ab745e9f67efc41c2dd0407220ab1cda3f34bd80afa5b7d7f465433c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/edit_content.html.twig", "@FOSUser/Group/edit.html.twig", 4)->display($context);
        
        $__internal_c480d98ab745e9f67efc41c2dd0407220ab1cda3f34bd80afa5b7d7f465433c7->leave($__internal_c480d98ab745e9f67efc41c2dd0407220ab1cda3f34bd80afa5b7d7f465433c7_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Group/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/edit_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Group/edit.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Group\\edit.html.twig");
    }
}
