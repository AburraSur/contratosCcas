<?php

/* @FOSUser/Group/list.html.twig */
class __TwigTemplate_f897f44fa8e4805d8273a5a9505204bcbcb1238dcd9cf3bac5f0f83b125cc5ae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Group/list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0a13c46a50301a28ed869c925056814d0970e7f4ceccd269c865dbd1e44f294d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0a13c46a50301a28ed869c925056814d0970e7f4ceccd269c865dbd1e44f294d->enter($__internal_0a13c46a50301a28ed869c925056814d0970e7f4ceccd269c865dbd1e44f294d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Group/list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0a13c46a50301a28ed869c925056814d0970e7f4ceccd269c865dbd1e44f294d->leave($__internal_0a13c46a50301a28ed869c925056814d0970e7f4ceccd269c865dbd1e44f294d_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_689ed6f5e61e21a33fd40735d70c833178ce09a0298790aad6cb3c9f9c8fff18 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_689ed6f5e61e21a33fd40735d70c833178ce09a0298790aad6cb3c9f9c8fff18->enter($__internal_689ed6f5e61e21a33fd40735d70c833178ce09a0298790aad6cb3c9f9c8fff18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/list_content.html.twig", "@FOSUser/Group/list.html.twig", 4)->display($context);
        
        $__internal_689ed6f5e61e21a33fd40735d70c833178ce09a0298790aad6cb3c9f9c8fff18->leave($__internal_689ed6f5e61e21a33fd40735d70c833178ce09a0298790aad6cb3c9f9c8fff18_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Group/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/list_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Group/list.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Group\\list.html.twig");
    }
}
