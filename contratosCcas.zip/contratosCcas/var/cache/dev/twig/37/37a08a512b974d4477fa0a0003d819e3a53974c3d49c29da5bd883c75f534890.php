<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_16d30d6c8e6ae904013d6547e31ba1806d01f3e241fdb0e81fc6eff944ab4106 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2b9f477a6c9111ca6dd68c16ca5a1d154a4f6f8e9d4f170199cd31c4026a952 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2b9f477a6c9111ca6dd68c16ca5a1d154a4f6f8e9d4f170199cd31c4026a952->enter($__internal_b2b9f477a6c9111ca6dd68c16ca5a1d154a4f6f8e9d4f170199cd31c4026a952_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_b2b9f477a6c9111ca6dd68c16ca5a1d154a4f6f8e9d4f170199cd31c4026a952->leave($__internal_b2b9f477a6c9111ca6dd68c16ca5a1d154a4f6f8e9d4f170199cd31c4026a952_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
