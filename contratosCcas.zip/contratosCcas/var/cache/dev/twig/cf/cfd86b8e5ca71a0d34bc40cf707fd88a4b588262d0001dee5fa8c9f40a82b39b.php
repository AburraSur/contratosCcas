<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_4a05530a5983dd0d9beb57e81b5bd19b6968c63cf21a5f5545098cb0524fbf17 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c483b20bd1b144ff33fe0d6a345fd36529e6560a51f6de181dcdf72cda4f9287 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c483b20bd1b144ff33fe0d6a345fd36529e6560a51f6de181dcdf72cda4f9287->enter($__internal_c483b20bd1b144ff33fe0d6a345fd36529e6560a51f6de181dcdf72cda4f9287_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_c483b20bd1b144ff33fe0d6a345fd36529e6560a51f6de181dcdf72cda4f9287->leave($__internal_c483b20bd1b144ff33fe0d6a345fd36529e6560a51f6de181dcdf72cda4f9287_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\container_attributes.html.php");
    }
}
