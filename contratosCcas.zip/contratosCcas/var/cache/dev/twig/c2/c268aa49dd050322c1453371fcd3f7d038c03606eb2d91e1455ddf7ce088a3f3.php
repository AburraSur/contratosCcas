<?php

/* @FOSUser/Registration/register.html.twig */
class __TwigTemplate_0acdb8c4eeb4d783a0440c53d2a52a058d45f2224a1aa6d190155d9b1994a16d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Registration/register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c03fc1216ebad288ed6d4d8949c01438e2ff1bbba0be1e50c3b9e0483f70346b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c03fc1216ebad288ed6d4d8949c01438e2ff1bbba0be1e50c3b9e0483f70346b->enter($__internal_c03fc1216ebad288ed6d4d8949c01438e2ff1bbba0be1e50c3b9e0483f70346b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Registration/register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c03fc1216ebad288ed6d4d8949c01438e2ff1bbba0be1e50c3b9e0483f70346b->leave($__internal_c03fc1216ebad288ed6d4d8949c01438e2ff1bbba0be1e50c3b9e0483f70346b_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_a5c022639cf561fbbd72b3522767745d828c9417da3da3fdefb11ca431624fc9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5c022639cf561fbbd72b3522767745d828c9417da3da3fdefb11ca431624fc9->enter($__internal_a5c022639cf561fbbd72b3522767745d828c9417da3da3fdefb11ca431624fc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Registration/register_content.html.twig", "@FOSUser/Registration/register.html.twig", 4)->display($context);
        
        $__internal_a5c022639cf561fbbd72b3522767745d828c9417da3da3fdefb11ca431624fc9->leave($__internal_a5c022639cf561fbbd72b3522767745d828c9417da3da3fdefb11ca431624fc9_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Registration/register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Registration/register_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Registration/register.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Registration\\register.html.twig");
    }
}
