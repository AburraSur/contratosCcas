<?php

/* default/adminHome.html.twig */
class __TwigTemplate_5bfe81e38d0caf62de5a2c020337ff675ab0641ebb59273daf82e35d723be59b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base1.html.twig", "default/adminHome.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e208feea1db14c497d96f70b13b8f5b8ba6cc254011f120c86b51caec6667116 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e208feea1db14c497d96f70b13b8f5b8ba6cc254011f120c86b51caec6667116->enter($__internal_e208feea1db14c497d96f70b13b8f5b8ba6cc254011f120c86b51caec6667116_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/adminHome.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e208feea1db14c497d96f70b13b8f5b8ba6cc254011f120c86b51caec6667116->leave($__internal_e208feea1db14c497d96f70b13b8f5b8ba6cc254011f120c86b51caec6667116_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_8d5a745b96cf3caef7f63b90fdd30fd450cfd8d8913f77a32a179b58be360428 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d5a745b96cf3caef7f63b90fdd30fd450cfd8d8913f77a32a179b58be360428->enter($__internal_8d5a745b96cf3caef7f63b90fdd30fd450cfd8d8913f77a32a179b58be360428_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    Hola ";
        echo twig_escape_filter($this->env, (isset($context["usuarioLogueado"]) ? $context["usuarioLogueado"] : $this->getContext($context, "usuarioLogueado")), "html", null, true);
        echo "
    <a href=\"#\" class=\"btn btn-success\" >BOTON BOOSTRAP</a>
";
        
        $__internal_8d5a745b96cf3caef7f63b90fdd30fd450cfd8d8913f77a32a179b58be360428->leave($__internal_8d5a745b96cf3caef7f63b90fdd30fd450cfd8d8913f77a32a179b58be360428_prof);

    }

    public function getTemplateName()
    {
        return "default/adminHome.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base1.html.twig' %}

{% block content %}
    Hola {{ usuarioLogueado }}
    <a href=\"#\" class=\"btn btn-success\" >BOTON BOOSTRAP</a>
{% endblock %}
", "default/adminHome.html.twig", "C:\\Bitnami\\wampstack-5.6.29-0\\apache2\\htdocs\\contratosCcas\\app\\Resources\\views\\default\\adminHome.html.twig");
    }
}
